$("#main-container").scroll(function() {
    $(".announcement").css("display", "none");
});